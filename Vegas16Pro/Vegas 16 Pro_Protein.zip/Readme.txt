- Install Vegas Pro 16.

- Replace patched file in the following path:

C:\Program Files\VEGAS\VEGAS Pro 16.0\Protein